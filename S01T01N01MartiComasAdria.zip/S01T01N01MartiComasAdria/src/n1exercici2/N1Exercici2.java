package n1exercici2;

public class N1Exercici2 {

	public static void main(String[] args) {
		
		Cotxe cotxe1 = new Cotxe(1500);
		
		Cotxe.frenar();
		cotxe1.accelerar();
		
	}

}
