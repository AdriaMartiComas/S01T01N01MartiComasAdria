package n1exercici1;

public class InstrumentVent extends Instrument {

	public InstrumentVent(String nom, int preu) {
		super(nom, preu);
	}

	@Override
	public void tocar() {
		System.out.println("Està sonant un instrument de vent");
	}

}
